﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LarkFramework;

public class Photon_Example : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            SendRequest();
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {

        }
    }

    void SendRequest()
    {
        Dictionary<byte, object> data = new Dictionary<byte, object>();
        data.Add(1, 100);
        data.Add(2, "测试数据");
        SingletonMono<PhotonManager>.Instance.Peer.OpCustom(1, data, true);
    }
}
