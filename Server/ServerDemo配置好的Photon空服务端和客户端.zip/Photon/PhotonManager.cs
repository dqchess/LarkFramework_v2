﻿using ExitGames.Client.Photon;
using LarkFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhotonManager : SingletonMono<PhotonManager>,IPhotonPeerListener
{
    public string ipAddress;                //服务器Ip地址
    public string port;                     //服务器端口号
    public string applicationName;          //服务器应用名

    //连接方式
    public ConnectionProtocol connectionProtocol=ConnectionProtocol.Udp;

    public const string LOG_TAG = "[PhotonManager]";

    private PhotonPeer peer;
    public PhotonPeer Peer { get { return peer; } }

    public void Init()
    {
        //通过Listender接收服务器端的响应
        peer = new PhotonPeer(this, connectionProtocol);
        peer.Connect(ipAddress+":"+ port, applicationName);

        this.Log(LOG_TAG + "Init Finished");
    }

    private void Update()
    {
        if (peer != null)
        {
            peer.Service();     //photon规定必须调用,检测服务连接
        }
    }

    private void OnDestroy()
    {
        if (peer!=null && peer.PeerState == PeerStateValue.Connected)
        {
            peer.Disconnect();      //断开连接
        }
    }

    public void DebugReturn(DebugLevel level, string message)
    {

    }

    public void OnEvent(EventData eventData)
    {
        switch (eventData.Code)
        {
            case 1:
                Dictionary<byte, object> data = eventData.Parameters;
                object intValue;
                data.TryGetValue(5, out intValue);
                object stringValue;
                data.TryGetValue(6, out stringValue);
                Debug.Log(string.Format("[Peer]<5,{0}>,<6,{1}>", intValue, stringValue));
                break;

            case 2:
                break;

            default:
                break;
        }
    }

    public void OnOperationResponse(OperationResponse operationResponse)
    {
        switch (operationResponse.OperationCode)
        {
            case 1:
                Dictionary<byte, object> data = operationResponse.Parameters;
                object intValue;
                data.TryGetValue(3, out intValue);
                object stringValue;
                data.TryGetValue(4, out stringValue);
                Debug.Log(string.Format("[Peer]<3,{0}>,<4,{1}>", intValue, stringValue));
                break;

            case 2:
                break;

            default:
                break;
        }
    }

    /// <summary>
    /// 当连接状态改变的时候
    /// </summary>
    /// <param name="statusCode"></param>
    public void OnStatusChanged(StatusCode statusCode)
    {
        Debug.Log(statusCode);
    }
}
