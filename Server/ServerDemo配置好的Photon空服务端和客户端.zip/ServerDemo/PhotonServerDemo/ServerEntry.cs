﻿using ExitGames.Logging;
using ExitGames.Logging.Log4Net;
using log4net.Config;
using Photon.SocketServer;
using System.IO;

namespace PhotonServerDemo
{
    /// <summary>
    /// 所有的Server端的入口类都集成自ApplicationBase
    /// </summary>
    public class ServerEntry : ApplicationBase
    {
        public static readonly ILogger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 当客户端请求链接
        /// peerBase为一个客户端连接
        /// </summary>
        /// <param name="initRequest"></param>
        /// <returns></returns>
        protected override PeerBase CreatePeer(InitRequest initRequest)
        {
            log.Info("[Peer]Link Start!");
            return new Client(initRequest);
        }

        /// <summary>
        /// 服务器启动
        /// </summary>
        protected override void Setup()
        {
            #region 日志初始化
            //设置日志所在路径
            log4net.GlobalContext.Properties["Photon:ApplicationLogPath"] = Path.Combine(this.ApplicationRootPath,"log");
            FileInfo configFileInfo = new FileInfo(Path.Combine(this.BinaryPath, "log4net.config"));
            if (configFileInfo.Exists)
            {
                LogManager.SetLoggerFactory(Log4NetLoggerFactory.Instance); //让Photon识别日志插件
                XmlConfigurator.ConfigureAndWatch(configFileInfo);  //读取配置文件
            }
            log.Info("[Log]Init Completed!");
            #endregion

            log.Info("[Server]Setup Completed!");
        }

        /// <summary>
        /// 服务器关闭
        /// </summary>
        protected override void TearDown()
        {
            log.Info("[Server]TearDown Completed!");
        }
    }
}
